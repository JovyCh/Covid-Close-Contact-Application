package model;

import java.io.Serializable;

public class contact implements Serializable{
    private String firstName = null;
    private String lastName = null;
    private int id;
    private int phonenumber;

    public contact() {
    }

    public contact(String firstName, String lastName, int id, int phone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.id = id;
        this.phonenumber = phone;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public int getid() {
        return id;
    }

    public void setid(int id) {
        this.id = id;
    }
    
    public int getphone() {
        return phonenumber;
    }

    public void setphone(int phone) {
        this.phonenumber = phone;
    }
    

    public String toString() {
    	return "\nFirst Name:\t\t" + firstName + "\nLast Name:\t\t" + lastName + "\nID:\t\t\t\t" + id + "\nPhone Number:\t" + phonenumber 
		+ "\n";
    }
    
}
